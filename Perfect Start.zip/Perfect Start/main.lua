return function(mod)
  
  local Game = package.loaded["src.core.Game"] or require("src.core.Game")
  
  if Game and Game.update then
    local originalUpdate = Game.update
    
    Game.update = function(game, dt)
      -- Run the vanilla update loop first
      local result
      if originalUpdate then result = originalUpdate(game, dt) end
      
      local save = game.save
      
      -- Wait until the engine officially flags that Oak has finished giving you the starter!
      if save and save.flags and save.flags.EVENT_GOT_STARTER and not save.hasAllStarters then
        
        -- Ensure the engine has initialized the party array
        if save.party and #save.party > 0 then
          
          -- Lock the event permanently so it doesn't run infinitely
          save.hasAllStarters = true
          
          -- Grab the engine's native script command module!
          local Commands = package.loaded["src.script.Commands"] or require("src.script.Commands")
          
          if Commands and Commands.give_pokemon then
            
            -- We build a fake context object exactly like the map scripts do
            local ctx = { game = game, save = save }
            
            -- Use the exact engine flags to determine which ones to silently inject!
            -- Because these use the native command, your Perfect DV mod will STILL automatically buff them!
            if not save.flags.EVENT_CHOSE_BULBASAUR then 
              Commands.give_pokemon(ctx, "BULBASAUR", 5) 
            end
            
            if not save.flags.EVENT_CHOSE_CHARMANDER then 
              Commands.give_pokemon(ctx, "CHARMANDER", 5) 
            end
            
            if not save.flags.EVENT_CHOSE_SQUIRTLE then 
              Commands.give_pokemon(ctx, "SQUIRTLE", 5) 
            end
            
            mod.log:info("Perfect Start: Successfully injected missing starters via native Commands!")
          else
            mod.log:error("All Starters Mod: Could not load the Commands module.")
          end
          
        end
      end
      
      return result
    end
  else
    mod.log:error("All Starters Mod: Could not locate core Game module.")
  end

end
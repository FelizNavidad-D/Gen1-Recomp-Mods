return function(mod)
  -- =====================================================================
  -- PC Grid UI Mod (Full Color Unique Icons Repair & Modern UI)
  -- Replaces the standard vertical list in the PC Box with a 5x4 
  -- visual grid featuring animated mini-sprites, native borders, 
  -- modern seamless box switching, and full party management options.
  -- =====================================================================

  mod.options:define({
    { key = "modernUiStyle", label = "MODERN UI STYLE", type = "toggle", default = true, description = "Enable the Modern UI aesthetic for the PC Box (requires Gen1 Modern UI mod to be active)." }
  })

  local Font = require("src.render.Font")
  local Strings = require("src.core.Strings")
  local Stats = require("src.pokemon.Stats")
  local Party = require("src.pokemon.Party")
  local TextBox = require("src.render.TextBox")
  
  local Assets = require("src.render.Assets")
  local Sprites = require("src.pokemon.Sprites")
  local PartyMenu = require("src.ui.PartyMenu")
  local Boxes = require("src.pokemon.Boxes")
  local Menu = require("src.ui.Menu")
  local ChoiceBox = require("src.ui.ChoiceBox")

  -- ---------------------------------------------------------------------
  -- PART 1: Icon Rendering Helper Functions
  -- ---------------------------------------------------------------------
  local iconCache = {}
  local modernFonts = {}

  local function getObpIcon(path)
    if not (love.image and love.image.newImageData) then
      return love.graphics.newImage(Assets.resolve(path))
    end
    local id = Assets.imageData(path)
    id:mapPixel(function(_, _, r, g, b, a)
      local luma = 0.299 * r + 0.587 * g + 0.114 * b
      local v = 0
      if luma > 0.8 then v = 1
      elseif luma > 0.5 then v = 170 / 255
      elseif luma > 0.2 then v = 85 / 255
      else v = 0 end
      return v, v, v, a
    end)
    return love.graphics.newImage(id)
  end

  local function isTrueColorIcon(game, species)
    local ok, PartyMenuCheck = pcall(require, "src.ui.PartyMenu")
    if ok and PartyMenuCheck and PartyMenuCheck._uniqueMenuIconsTrueColorWrapped then
      return true
    end
    return false
  end

  local function getIconPath(game, species)
    local icons = game.data.icons
    if not icons then return nil, nil end
    local def = game.data.pokemon[species]
    local entry = (icons.bySpecies and icons.bySpecies[species]) or (def and def.icon)
    local name, path
    if type(entry) == "string" then
      name = entry; path = icons.icons and icons.icons[entry]
    elseif type(entry) == "table" then
      path = entry.image
    end
    if not path then
      name = def and def.dex and icons.byDex and icons.byDex[def.dex]
      path = name and icons.icons and icons.icons[name]
    end
    return Sprites.iconPath(game.data, {species=species}, path, { name = name }), name
  end

  local function getHighResIconData(game, species)
      if species == "BALL" then
          local icons = game.data.icons
          local ballPath = icons and icons.icons and (icons.icons["BALL"] or icons.icons["ball"])
          if not ballPath then return nil end
          local key = ballPath .. "#raw"
          if iconCache[key] == nil then
              local ok, img = pcall(love.graphics.newImage, Assets.resolve(ballPath))
              iconCache[key] = ok and img or false
          end
          return iconCache[key], true 
      end

      local iconPath, iconName = getIconPath(game, species)
      if not iconPath then return nil end
      local trueColor = isTrueColorIcon(game, species)
      local key = trueColor and (iconPath .. "#raw") or (iconName and (iconPath .. "#obp") or iconPath)
      
      if iconCache[key] == nil then
         local ok, img
         if trueColor then
             ok, img = pcall(love.graphics.newImage, Assets.resolve(iconPath))
         elseif iconName then
             ok, img = pcall(getObpIcon, iconPath)
         else
             ok, img = pcall(love.graphics.newImage, Assets.resolve(iconPath))
         end
         iconCache[key] = ok and img or false
      end
      return iconCache[key], trueColor
  end

  local function drawBoxIconScaled(game, mon, x, y, isSelected, blinkCounter, scale, pOpac)
      -- Try Wilds of Kanto follower sprite (respects sprite style + color mode).
      local wildsSvc = rawget(_G, "_wildsSpriteService")
      if wildsSvc and type(wildsSvc.resolvePartyIconDef) == "function" then
        local fdef = wildsSvc:resolvePartyIconDef(mon, game)
        if fdef and fdef.image then
          local fimg = wildsSvc:getPartyIconImage(fdef.image)
          if fimg then
            local fw, fh = fimg:getWidth(), fimg:getHeight()
            local frames = tonumber(fdef.frames) or 1
            local frameH = frames > 1 and math.floor(fh / frames) or fh
            local quad = love.graphics.newQuad(0, 0, fw, frameH, fw, fh)
            local sx, sy = scale, scale
            if fw > 16 or frameH > 16 then
              local boxSize = 16 * scale
              sx, sy = boxSize / fw, boxSize / frameH
            end
            local trueColor = fdef.trueColor ~= false
            local prevShader = nil
            if trueColor and love.graphics.getShader then
              prevShader = love.graphics.getShader()
              love.graphics.setShader()
            end
            love.graphics.setColor(1, 1, 1, pOpac or 1)
            love.graphics.draw(fimg, quad, x, y, 0, sx, sy)
            if trueColor then
              local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
              if okFX and PaletteFX and PaletteFX.markTrueColor then
                PaletteFX.markTrueColor(x, y, fw * sx, frameH * sy)
              end
              if prevShader and love.graphics.setShader then
                love.graphics.setShader(prevShader)
              end
            end
            return
          end
        end
      end

      local img, trueColor = getHighResIconData(game, mon.species)
      if not img then return end
      
      local alt = false
      if isSelected then alt = math.floor(blinkCounter / 16) % 2 == 1 end
      
      local iw, ih = img:getDimensions()
      local _, iconName = getIconPath(game, mon.species)
      
      local jumpY = 0
      if alt and (iconName == "BALL" or iconName == "HELIX") then
          jumpY = 1 * scale
          alt = false
      end

      local frame = ih > 16 and PartyMenu.frameFor(iconName or "GENERIC", alt, ih) or 0
      local prevShader = love.graphics.getShader()
      local appliedShader = false

      love.graphics.setColor(1, 1, 1, pOpac or 1)
      if not trueColor and mon.species ~= "BALL" then
          local ok, PaletteFX = pcall(require, "src.render.PaletteFX")
          if ok and PaletteFX and PaletteFX.monPal then
              local pal = PaletteFX.monPal(game.data, mon.species)
              if pal then
                  local shader = PaletteFX.shader()
                  if shader then
                      pcall(PaletteFX.sendColors, shader, pal)
                      love.graphics.setShader(shader)
                      appliedShader = true
                  end
              end
          end
      end

      local isMirrored = iconName and PartyMenu.mirrorsIcon(iconName)
      
      if isMirrored then
          local half = love.graphics.newQuad(0, frame * 16, 8, 16, iw, ih)
          love.graphics.draw(img, half, x, y + jumpY, 0, scale, scale)
          love.graphics.draw(img, half, x + 16 * scale, y + jumpY, 0, -scale, scale)
      elseif ih > 16 then
          local quad = love.graphics.newQuad(0, frame * 16, 16, 16, iw, ih)
          love.graphics.draw(img, quad, x, y + jumpY, 0, scale, scale)
      else
          love.graphics.draw(img, x, y + jumpY, 0, scale, scale)
      end

      if appliedShader then love.graphics.setShader(prevShader) end

      if trueColor or appliedShader then
          local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
          if okFX and PaletteFX and PaletteFX.markTrueColor then
              PaletteFX.markTrueColor(x, y + jumpY, 16 * scale, 16 * scale)
          end
      end
  end

  local function getLargeSprite(game, species)
      if not species then return nil end
      local def = game.data.pokemon[species]
      if not def then return nil end
      
      local path = def.spriteFront
      local ok, SpritesReq = pcall(require, "src.pokemon.Sprites")
      if ok and SpritesReq and type(SpritesReq.path) == "function" then
          local p = SpritesReq.path(game.data, species, "front", {kind = "summary"})
          if p then path = p end
      end
      
      if not path then return nil end
      local okImg, img = pcall(love.graphics.newImage, Assets.resolve(path))
      if okImg and img then
          img:setFilter("nearest", "nearest")
          return img 
      end
      return nil
  end

  -- ---------------------------------------------------------------------
  -- PART 2: Custom PC Grid Class
  -- ---------------------------------------------------------------------
  local activePcGrid = nil
  local PcGrid = {}
  PcGrid.__index = PcGrid

  function PcGrid.new(game, boxData)
    local self = setmetatable({}, PcGrid)
    self.game = game
    self.boxData = boxData
    self.index = 1
    self.blink = 0
    self.subMenuOpen = false
    self.subMenuIndex = 1
    self.isPcGrid = true
    -- FIX: Expose a valid screenId so Modern UI's pointer scanner doesn't crash!
    self.screenId = "PC_GRID_VIEW" 
    return self
  end

  function PcGrid:update(dt)
    activePcGrid = self
    self.blink = (self.blink + 1) % 320
    local input = self.game.input

    local forceClassic = mod.options:get("modernUiStyle") == false
    local modernMod = mod.find and mod.find("gen1_modern_ui")
    local opts = self.game.save and self.game.save.options and self.game.save.options.modOptions and self.game.save.options.modOptions["gen1_modern_ui"] or {}
    local isModern = modernMod and opts.menuUi ~= false and not forceClassic
    
    if isModern then
        self.draw = function() end
    else
        self.draw = nil
    end
    
    if isModern and self.subMenuOpen then
        if input:wasPressed("b") then
            require("src.core.Sound").play(self.game.data, "Press_AB")
            self.subMenuOpen = false
        elseif input:wasPressed("up") then
            self.subMenuIndex = self.subMenuIndex > 1 and self.subMenuIndex - 1 or 4
        elseif input:wasPressed("down") then
            self.subMenuIndex = self.subMenuIndex < 4 and self.subMenuIndex + 1 or 1
        elseif input:wasPressed("a") then
            require("src.core.Sound").play(self.game.data, "Press_AB")
            local mon = self.boxData[self.index]
            if not mon then return end
            
            local def = self.game.data.pokemon[mon.species]
            local name = mon.nickname or def.name
            
            if self.subMenuIndex == 1 then -- WITHDRAW
                if #(self.game.save.party) >= Party.MAX then
                    self.subMenuOpen = false
                    self.game.stack:push(TextBox.new(self.game, "The party is full!"))
                    return
                end
                Stats.ensure(self.game.data.pokemon[mon.species], mon)
                table.remove(self.boxData, self.index)
                table.insert(self.game.save.party, mon)
                self.game.stringBuffer = name
                require("src.core.Sound").playCry(self.game.data, mon.species)
                activePcGrid = nil
                self.game.stack:pop() 
                self.game.stack:pop() 
                self.game.stack:push(TextBox.new(self.game, Strings("%s is\ntaken out.\vGot %s.", name, name)))
            elseif self.subMenuIndex == 2 then -- CHANGE
                self.subMenuOpen = false
                local partyMenu = require("src.ui.Screens").push(self.game, "PartyMenu", {
                    pickOnly = true,
                    onSwitch = function(partyMon, partyMenuRef)
                        local partyIndex = partyMenuRef.index
                        Stats.ensure(self.game.data.pokemon[mon.species], mon)
                        self.boxData[self.index] = partyMon
                        self.game.save.party[partyIndex] = mon
                        local pDef = self.game.data.pokemon[partyMon.species]
                        local pName = partyMon.nickname or pDef.name
                        require("src.core.Sound").play(self.game.data, "Swap")
                        self.game.stack:push(TextBox.new(self.game, Strings("Swapped %s\nwith %s!", pName, name)))
                    end
                })
                if partyMenu then
                    rawset(partyMenu, "draw", nil)
                end
            elseif self.subMenuIndex == 3 then -- RELEASE
                self.subMenuOpen = false
                self.game.stack:push(TextBox.new(self.game, Strings("Once released,\n%s is\ngone forever. OK?", name), function()
                    self.game.stack:push(ChoiceBox.new(self.game, function(yes)
                        if not yes then return end
                        table.remove(self.boxData, self.index)
                        require("src.core.Sound").playCry(self.game.data, mon.species)
                        self.game.stack:push(TextBox.new(self.game, Strings("%s was\nreleased outside.\fBye %s!", name, name)))
                    end, { defaultNo = true, noSound = true }))
                end))
            elseif self.subMenuIndex == 4 then -- CANCEL
                self.subMenuOpen = false
            end
        end
        return 
    end

    if input:wasPressed("b") then
      require("src.core.Sound").play(self.game.data, "Press_AB")
      activePcGrid = nil
      self.game.stack:pop()
      return
    end
    
    if input:wasPressed("a") then
      local mon = self.boxData[self.index]
      if mon then
        require("src.core.Sound").play(self.game.data, "Press_AB")
        
        if isModern then
            self.subMenuOpen = true
            self.subMenuIndex = 1
        else
            local def = self.game.data.pokemon[mon.species]
            local name = mon.nickname or def.name
            
            self.game.stack:push(Menu.new(self.game, {
              { label = "WITHDRAW", onSelect = function()
                  if #(self.game.save.party) >= Party.MAX then
                    self.game.stack:push(TextBox.new(self.game, "The party is full!"))
                    return
                  end
                  Stats.ensure(self.game.data.pokemon[mon.species], mon)
                  table.remove(self.boxData, self.index)
                  table.insert(self.game.save.party, mon)
                  self.game.stringBuffer = name
                  require("src.core.Sound").playCry(self.game.data, mon.species)
                  activePcGrid = nil
                  self.game.stack:pop() 
                  self.game.stack:pop() 
                  self.game.stack:push(TextBox.new(self.game, Strings("%s is\ntaken out.\vGot %s.", name, name)))
              end },
              { label = "CHANGE", onSelect = function()
                  self.game.stack:pop() 
                  local partyMenu = require("src.ui.Screens").push(self.game, "PartyMenu", {
                    pickOnly = true,
                    onSwitch = function(partyMon, partyMenuRef)
                      local partyIndex = partyMenuRef.index
                      Stats.ensure(self.game.data.pokemon[mon.species], mon)
                      self.boxData[self.index] = partyMon
                      self.game.save.party[partyIndex] = mon
                      local pDef = self.game.data.pokemon[partyMon.species]
                      local pName = partyMon.nickname or pDef.name
                      require("src.core.Sound").play(self.game.data, "Swap")
                      self.game.stack:push(TextBox.new(self.game, Strings("Swapped %s\nwith %s!", pName, name)))
                    end
                  })
                  if partyMenu then
                      rawset(partyMenu, "draw", nil)
                  end
              end },
              { label = "RELEASE", onSelect = function()
                  self.game.stack:pop() 
                  self.game.stack:push(TextBox.new(self.game, Strings("Once released,\n%s is\ngone forever. OK?", name), function()
                    self.game.stack:push(ChoiceBox.new(self.game, function(yes)
                      if not yes then return end
                      table.remove(self.boxData, self.index)
                      require("src.core.Sound").playCry(self.game.data, mon.species)
                      self.game.stack:push(TextBox.new(self.game, Strings("%s was\nreleased outside.\fBye %s!", name, name)))
                    end, { defaultNo = true, noSound = true }))
                  end))
              end },
              { label = "STATS", keepOpen = true, onSelect = function()
                  require("src.ui.Screens").push(self.game, "SummaryMenu", mon)
              end },
              { label = "CANCEL" }
            }, { tx = 9, ty = 6, tw = 11, th = 12, noSound = true }))
        end
      else
        require("src.core.Sound").play(self.game.data, "Collision")
      end
      return
    end

    if input:wasPressed("up") then
      self.index = self.index - 5
      if self.index < 1 then self.index = self.index + 20 end
    elseif input:wasPressed("down") then
      self.index = self.index + 5
      if self.index > 20 then self.index = self.index - 20 end
    elseif input:wasPressed("left") then
      if self.index % 5 == 1 then 
        self.game.save.currentBox = (self.game.save.currentBox or 1) - 1
        if self.game.save.currentBox < 1 then self.game.save.currentBox = Boxes.COUNT end
        self.boxData = Boxes.active(self.game.save)
        self.index = self.index + 4
      else 
        self.index = self.index - 1 
      end
    elseif input:wasPressed("right") then
      if self.index % 5 == 0 then 
        self.game.save.currentBox = (self.game.save.currentBox or 1) + 1
        if self.game.save.currentBox > Boxes.COUNT then self.game.save.currentBox = 1 end
        self.boxData = Boxes.active(self.game.save)
        self.index = self.index - 4
      else 
        self.index = self.index + 1 
      end
    end
  end

  function PcGrid:draw()
    local opts = self.game.save and self.game.save.options and self.game.save.options.modOptions and self.game.save.options.modOptions["gen1_modern_ui"] or {}
    local forceClassic = mod.options:get("modernUiStyle") == false
    local modernMod = mod.find and mod.find("gen1_modern_ui")
    local isModern = modernMod and opts.menuUi ~= false and not forceClassic
    
    if isModern then
        return
    end

    local ok, err = pcall(function()
      local cr, cg, cb, ca = love.graphics.getColor()
      love.graphics.setColor(1, 1, 1, 0.40)
      love.graphics.rectangle("fill", 0, 0, 160, 144)
      love.graphics.setColor(cr, cg, cb, ca)
      
      local prev_translucent = Font.__translucent_active
      Font.__translucent_active = true

      Font.drawBox(0, 0, 20, 18)

      for i = 1, 20 do
        local col = ((i - 1) % 5)
        local row = math.floor((i - 1) / 5)
        local x = col * 32
        local y = row * 24
        local mon = self.boxData[i]

        if i == self.index then
          love.graphics.setScissor(x, y, 32, 8)
          Font.drawBox(col * 4, row * 3, 4, 3)
          love.graphics.setScissor(x, y + 16, 32, 8)
          Font.drawBox(col * 4, row * 3, 4, 3)
          love.graphics.setScissor(x, y + 8, 8, 8)
          Font.drawBox(col * 4, row * 3, 4, 3)
          love.graphics.setScissor(x + 24, y + 8, 8, 8)
          Font.drawBox(col * 4, row * 3, 4, 3)
          love.graphics.setScissor()
        end

        if mon then
          drawBoxIconScaled(self.game, mon, x + 8, y + 4, i == self.index, self.blink, 1, 1)
        else
          love.graphics.setColor(0.6, 0.6, 0.6, 1)
          love.graphics.rectangle("fill", x + 12, y + 11, 8, 2)
        end
      end

      Font.drawBox(0, 12, 20, 6)
      love.graphics.setColor(0, 0, 0, 1)
      local hoveredMon = self.boxData[self.index]
      
      if hoveredMon then
        local def = self.game.data.pokemon[hoveredMon.species] or {}
        local name = hoveredMon.nickname or def.name or hoveredMon.species
        Font.draw(Strings("%s", name), 8, 112)
        Font.draw(Strings(":L%d", hoveredMon.level or 0), 8, 128)
      else
        Font.draw(Strings("Empty Slot"), 8, 112)
      end
      
      local boxStr = Strings("BOX %d", self.game.save.currentBox or 1)
      Font.draw(boxStr, 152 - Font.width(boxStr), 128)
      
      love.graphics.setColor(1, 1, 1, 1)
      Font.__translucent_active = prev_translucent
    end)
    
    if not ok then
        print("PcGrid Classic Draw Error: " .. tostring(err))
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.setScissor()
    end
  end

  mod.content.screens:register("PC_GRID_VIEW", {
    new = function(game, boxData)
      return PcGrid.new(game, boxData)
    end
  })

  -- ---------------------------------------------------------------------
  -- PART 4: Monkey-patch BoxMenu to prevent engine background bleed
  -- ---------------------------------------------------------------------
  local okB, BoxMenu = pcall(require, "src.ui.BoxMenu")
  if okB and BoxMenu and not BoxMenu.__grid_wrapped then
    BoxMenu.__grid_wrapped = true
    
    -- Tell the base game engine to stop drawing the classic BoxMenu if our grid is up!
    local origDraw = BoxMenu.draw
    BoxMenu.draw = function(self)
      if activePcGrid then return end
      if origDraw then origDraw(self) end
    end
    
    local origNew = BoxMenu.new
    BoxMenu.new = function(game)
      local menu = origNew(game)
      
      for _, item in ipairs(menu.items) do
        if item.label == Strings("WITHDRAW <PK><MN>") then
          item.onSelect = function()
            local box = Boxes.active(game.save)
            if #box == 0 then
              game.stack:push(TextBox.new(game, Strings("What? There are\nno POKéMON here!")))
              return
            end
            mod.ui.push(game, "PC_GRID_VIEW", box)
          end
        end
      end
      
      return menu
    end
  end

  -- ---------------------------------------------------------------------
  -- PART 5: MODERN UI RENDER HOOK
  -- ---------------------------------------------------------------------
  local function getModernFont(size, opts)
      local doubleSize = size * 2
      local isPixel = opts.pixelFont ~= false
      local key = tostring(doubleSize) .. (isPixel and "_pixel" or "_smooth")
      
      if not modernFonts[key] then
          local f
          if isPixel then
              pcall(function() f = love.graphics.newFont("assets/fonts/plainpixel/PlainPixel-Regular.ttf", doubleSize) end)
              if not f then pcall(function() f = love.graphics.newFont(doubleSize) end) end
              if f then f:setFilter("nearest", "nearest") end
          else
              pcall(function() f = love.graphics.newFont(doubleSize) end)
              if f then f:setFilter("linear", "linear") end
          end
          modernFonts[key] = f or love.graphics.getFont()
      end
      return modernFonts[key]
  end

  local function printScaled(text, x, y, fontObj, colorArray)
      love.graphics.setColor(colorArray[1], colorArray[2], colorArray[3], colorArray[4] or 1)
      love.graphics.setFont(fontObj)
      love.graphics.print(text, math.floor(x), math.floor(y), 0, 0.5, 0.5)
  end

  local function getScaledWidth(text, fontObj) return fontObj:getWidth(text) * 0.5 end
  local function getScaledHeight(fontObj) return fontObj:getHeight() * 0.5 end

  local function resolveFrame(theme, opts, modernMod)
      local frame = {}
      if theme.frame then
          for k,v in pairs(theme.frame) do frame[k] = v end
      end
      local style = opts.frameStyle or "pixel"
      local asset = opts.frameAsset or "2"
      local scale = tonumber(opts.frameScale) or 2

      if style == "theme" and not frame.style then
          style = "pixel"
      end

      frame.style = style == "theme" and frame.style or style
      if frame.style == "plain" then frame.style = "none" end
      frame.pixelScale = scale

      if opts.frameStyle ~= "theme" then
          if asset == "1" then frame.asset = "assets/pixel_frame1.png"
          elseif asset == "2" then frame.asset = "assets/pixel_frame2.png"
          elseif asset == "3" then frame.asset = "assets/pixel_frame3.png"
          else frame.asset = asset end
      end

      if type(frame.asset) == "string" and modernMod and modernMod.exports and modernMod.exports.frames then
          local registered = modernMod.exports.frames[frame.asset]
          if registered then frame.asset = registered end
      end
      return frame
  end

  local function drawPanelFrame(frame, colors, x, y, w, h, radius, cAccent, cDivider)
      local style = frame.style or "pixel"
      if style == "none" then return end
      
      local width = math.max(1, tonumber(frame.width) or 3)
      local inset = math.max(0, tonumber(frame.inset) or 0)
      local margin = math.max(0, tonumber(frame.margin) or 0)
      local shadow = math.max(0, tonumber(frame.shadow) or 0)
      local lineRadius = style == "soft" and (radius or 22) or 0
      local fx, fy = x - margin + inset, y - margin + inset
      local fw = math.max(1, w + margin * 2 - inset * 2)
      local fh = math.max(1, h + margin * 2 - inset * 2)
      
      local frameColor = colors.frame or cAccent or {0.4, 0.6, 1, 1}
      local shadowColor = colors.frameShadow or cDivider or {0.5, 0.5, 0.5, 1}

      if style == "pixel" and frame.asset then
          local asset = frame.asset
          if type(asset) == "table" then
              asset = asset.asset or asset.image or asset.texture or asset.path
          end
          if type(asset) == "string" then
              local ok, img = pcall(love.graphics.newImage, asset)
              asset = ok and img or nil
          end
          
          if asset and type(asset) == "userdata" and type(asset.getWidth) == "function" then
              if type(asset.setFilter) == "function" then pcall(asset.setFilter, asset, "nearest", "nearest") end
              local iw, ih = asset:getWidth(), asset:getHeight()
              local pixelScale = math.max(1, math.floor(tonumber(frame.pixelScale) or 1))
              local dpiX = math.max(1, tonumber(frame.pixelDpiX) or 1)
              local dpiY = math.max(1, tonumber(frame.pixelDpiY) or 1)
              local function snapPixel(value, dpi, quantum)
                  local q = math.max(1, quantum or 1)
                  return math.floor(value * dpi / q + 0.5) * q / dpi
              end
              local panelX, panelY = snapPixel(x, dpiX, 1), snapPixel(y, dpiY, 1)
              local panelRight = snapPixel(x + w, dpiX, 1)
              local panelBottom = snapPixel(y + h, dpiY, 1)
              local panelW = math.max(pixelScale / dpiX, snapPixel(panelRight - panelX, dpiX, pixelScale))
              local panelH = math.max(pixelScale / dpiY, snapPixel(panelBottom - panelY, dpiY, pixelScale))
              local sourceSlice = math.max(1, math.min(math.floor(tonumber(frame.slice) or 24), math.floor(math.min(iw, ih) / 2)))
              local edgeScaleX, edgeScaleY = pixelScale / dpiX, pixelScale / dpiY
              local maxCornerSource = math.max(1, math.min(sourceSlice, math.floor(panelW / (2 * edgeScaleX) + 0.0001), math.floor(panelH / (2 * edgeScaleY) + 0.0001)))
              sourceSlice = maxCornerSource
              local destinationCornerX = sourceSlice * edgeScaleX
              local destinationCornerY = sourceSlice * edgeScaleY
              local sourceInset = math.max(0, math.min(tonumber(frame.pixelInset) or 7, sourceSlice))
              local frameMarginX = sourceInset * edgeScaleX
              local frameMarginY = sourceInset * edgeScaleY
              local assetFx, assetFy = panelX - frameMarginX, panelY - frameMarginY
              local assetFw = math.max(pixelScale / dpiX, panelW + frameMarginX * 2)
              local assetFh = math.max(pixelScale / dpiY, panelH + frameMarginY * 2)

              love.graphics.setColor(1, 1, 1, 1)
              local function drawSlice(sx, sy, sw, sh, dx, dy, dw, dh)
                  if sw <= 0 or sh <= 0 or dw <= 0 or dh <= 0 then return end
                  local quad = love.graphics.newQuad(sx, sy, sw, sh, iw, ih)
                  love.graphics.draw(asset, quad, dx, dy, 0, dw / sw, dh / sh)
              end
              local function drawTiledX(sx, sy, sw, sh, dx, dy, dw, dh)
                  if sw <= 0 or sh <= 0 or dw <= 0 or dh <= 0 then return end
                  local offset = 0
                  while offset < dw - 0.001 do
                      local sourceWidth = math.min(sw, math.floor((dw - offset) / edgeScaleX + 0.0001))
                      if sourceWidth < 1 then break end
                      local drawWidth = sourceWidth * edgeScaleX
                      drawSlice(sx, sy, sourceWidth, sh, dx + offset, dy, drawWidth, dh)
                      offset = offset + drawWidth
                  end
              end
              local function drawTiledY(sx, sy, sw, sh, dx, dy, dw, dh)
                  if sw <= 0 or sh <= 0 or dw <= 0 or dh <= 0 then return end
                  local offset = 0
                  while offset < dh - 0.001 do
                      local sourceHeight = math.min(sh, math.floor((dh - offset) / edgeScaleY + 0.0001))
                      if sourceHeight < 1 then break end
                      local drawHeight = sourceHeight * edgeScaleY
                      drawSlice(sx, sy, sw, sourceHeight, dx, dy + offset, dw, drawHeight)
                      offset = offset + drawHeight
                  end
              end
              local centerSourceW, centerSourceH = iw - sourceSlice * 2, ih - sourceSlice * 2
              local centerDestW, centerDestH = assetFw - destinationCornerX * 2, assetFh - destinationCornerY * 2
              
              drawSlice(0, 0, sourceSlice, sourceSlice, assetFx, assetFy, destinationCornerX, destinationCornerY)
              drawTiledX(sourceSlice, 0, centerSourceW, sourceSlice, assetFx + destinationCornerX, assetFy, centerDestW, destinationCornerY)
              drawSlice(iw - sourceSlice, 0, sourceSlice, sourceSlice, assetFx + assetFw - destinationCornerX, assetFy, destinationCornerX, destinationCornerY)
              drawTiledY(0, sourceSlice, sourceSlice, centerSourceH, assetFx, assetFy + destinationCornerY, destinationCornerX, centerDestH)
              drawTiledY(iw - sourceSlice, sourceSlice, sourceSlice, centerSourceH, assetFx + assetFw - destinationCornerX, assetFy + destinationCornerY, destinationCornerX, centerDestH)
              drawSlice(0, ih - sourceSlice, sourceSlice, sourceSlice, assetFx, assetFy + assetFh - destinationCornerY, destinationCornerX, destinationCornerY)
              drawTiledX(sourceSlice, ih - sourceSlice, centerSourceW, sourceSlice, assetFx + destinationCornerX, assetFy + assetFh - destinationCornerY, centerDestW, destinationCornerY)
              drawSlice(iw - sourceSlice, ih - sourceSlice, sourceSlice, sourceSlice, assetFx + assetFw - destinationCornerX, assetFy + assetFh - destinationCornerY, destinationCornerX, destinationCornerY)
              return
          end
      end

      if shadow > 0 then
          love.graphics.setColor(shadowColor[1], shadowColor[2], shadowColor[3], shadowColor[4] or 1)
          love.graphics.setLineWidth(width)
          love.graphics.rectangle("line", fx + shadow, fy + shadow, math.max(1, fw), math.max(1, fh), lineRadius)
      end
      love.graphics.setColor(frameColor[1], frameColor[2], frameColor[3], frameColor[4] or 1)
      love.graphics.setLineWidth(width)
      love.graphics.rectangle("line", fx, fy, fw, fh, lineRadius)
      love.graphics.setLineWidth(1)
  end

  mod.hooks:wrap("render.hud", function(nextFn, ...)
      local args = {...}
      local game = args[1]
      
      -- Safely locate the game object without breaking varargs
      if type(game) ~= "table" or not game.stack then 
          game = activePcGrid and activePcGrid.game 
      end
      if not game or not game.stack then return nextFn(unpack(args)) end
      
      local isGridActive = false
      for _, s in ipairs(game.stack.states) do
          if s == activePcGrid then isGridActive = true; break end
      end

      -- =========================================================================
      -- 1. STACK FILTERING (The Real Fix!)
      -- =========================================================================
      local originalStates = {}
      local modernStates = {}
      local isTop = false
      
      if isGridActive then
          local gridIndex = 0
          for i, s in ipairs(game.stack.states) do
              originalStates[i] = s
              if s == activePcGrid then gridIndex = i end
          end
          
          -- Check if PC Grid is the top-most active window
          isTop = (gridIndex == #originalStates)
          
          for i, s in ipairs(originalStates) do
              -- Keep the base Overworld (index 1)
              -- Keep any screen pushed explicitly ON TOP of our grid (like Party Menu)
              -- This completely annihilates the "SOMEONE'S PC" menu from Modern UI's vision!
              if i == 1 or i > gridIndex then
                  table.insert(modernStates, s)
              end
          end
          
          -- Swap the stack temporarily
          for i = #game.stack.states, 1, -1 do table.remove(game.stack.states, i) end
          for _, s in ipairs(modernStates) do table.insert(game.stack.states, s) end
      end

      -- =========================================================================
      -- 2. DRAW PC GRID MANUALLY (Behind the Party/Stats menus)
      -- =========================================================================
      if isGridActive then
          local ok, err = pcall(function()
              local opts = game.save and game.save.options and game.save.options.modOptions and game.save.options.modOptions["gen1_modern_ui"] or {}
              local forceClassic = mod.options:get("modernUiStyle") == false
              local modernMod = mod.find and mod.find("gen1_modern_ui")
              if not modernMod or opts.menuUi == false or forceClassic or type(modernMod.exports) ~= "table" then return end

              local w, h = love.graphics.getWidth(), love.graphics.getHeight()
              local sx, sy, sw, sh = 0, 0, w, h
              if love.window and love.window.getSafeArea then sx, sy, sw, sh = love.window.getSafeArea() end
              
              local themeId = opts.theme or "gen1_modern_ui:classic_mono"
              local theme = modernMod.exports.themes[themeId] or modernMod.exports.themes["default"]
              if not theme then return end
              
              local uiScale = 1
              local fontScale = 1
              if modernMod.exports.getScaleTokens then
                  local tokens = modernMod.exports.getScaleTokens({width = sw, height = sh})
                  uiScale = tokens.uiScale or 1
                  fontScale = tokens.fontScale or 1
              end
              
              local pOpac = (opts.panelOpacity or 100) / 100
              local fOpac = (opts.foregroundOpacity or 100) / 100
              
              local tC = theme.colors or {}
              local cSurface  = tC.surface or {0.05, 0.05, 0.05, 1}
              local cRaised   = tC.surfaceRaised or {0.15, 0.15, 0.15, 1}
              local cSelected = tC.selected or {0.2, 0.4, 0.8, 1}
              local cBackdrop = tC.backdrop or {0, 0, 0, 0.6}
              
              local function adapt(fg)
                  if not fg then return fg end
                  local bgLuma = 0.299 * (cSurface[1] or 0) + 0.587 * (cSurface[2] or 0) + 0.114 * (cSurface[3] or 0)
                  local fgLuma = 0.299 * (fg[1] or 0) + 0.587 * (fg[2] or 0) + 0.114 * (fg[3] or 0)
                  if math.abs(bgLuma - fgLuma) < 0.35 then
                      if bgLuma > 0.5 then return {0.15, 0.15, 0.15, (fg[4] or 1) * fOpac}
                      else return {0.95, 0.95, 0.95, (fg[4] or 1) * fOpac} end
                  end
                  return {fg[1], fg[2], fg[3], (fg[4] or 1) * fOpac}
              end

              local cText   = adapt(tC.text or {1, 1, 1, 1})
              local cMuted  = adapt(tC.textMuted or {0.6, 0.6, 0.6, 1})
              local cAccent = adapt(tC.accent or {0.4, 0.6, 1, 1})
              local cDivider = { (tC.divider or {0.5,0.5,0.5})[1], (tC.divider or {0.5,0.5,0.5})[2], (tC.divider or {0.5,0.5,0.5})[3], fOpac }

              local titleFont = getModernFont(math.floor((theme.typography and theme.typography.title or 24) * fontScale), opts)
              local bodyFont = getModernFont(math.floor((theme.typography and theme.typography.body or 17) * fontScale), opts)
              local captionFont = getModernFont(math.floor((theme.typography and theme.typography.caption or 13) * fontScale), opts)

              love.graphics.push("all")
              love.graphics.origin()

              -- Only draw the dark backdrop if the PC Grid is the top-most active window!
              if isTop then
                  love.graphics.setColor(cBackdrop[1], cBackdrop[2], cBackdrop[3], cBackdrop[4] or 1)
                  love.graphics.rectangle("fill", 0, 0, w, h)
              end

              local pad = 18 * uiScale
              local rad = (theme.radii and theme.radii.lg or 22) * uiScale
              
              local panelW = math.min(sw - 36 * uiScale, 800 * uiScale)
              local panelH = math.min(sh - 36 * uiScale, 620 * uiScale)
              local px = sx + (sw - panelW) / 2
              local py = sy + (sh - panelH) / 2

              love.graphics.setColor(cSurface[1], cSurface[2], cSurface[3], (cSurface[4] or 1) * pOpac)
              love.graphics.rectangle("fill", px, py, panelW, panelH, rad)

              local activeFrame = resolveFrame(theme, opts, modernMod)
              drawPanelFrame(activeFrame, theme.colors or {}, px, py, panelW, panelH, rad, cAccent, cDivider)

              if activeFrame.style ~= "pixel" then
                  love.graphics.setColor(cAccent[1], cAccent[2], cAccent[3], cAccent[4])
                  love.graphics.rectangle("fill", px, py, panelW, 4 * uiScale, rad)
                  love.graphics.rectangle("fill", px, py + 4 * uiScale, panelW, 2 * uiScale)
              end

              local title = Strings("BOX %d", game.save.currentBox or 1)
              printScaled(title, px + pad, py + pad, titleFont, cText)

              local headerH = getScaledHeight(titleFont) + 36 * uiScale
              local footerH = getScaledHeight(captionFont) + 26 * uiScale
              
              local detailW = math.min(380 * uiScale, panelW * 0.48)
              local gridAvailW = panelW - pad * 3 - detailW
              local gridAvailH = panelH - headerH - footerH - pad
              
              local cols, gridRows = 5, 4
              local cellSize = math.max(1, math.min(gridAvailW / cols, gridAvailH / gridRows))
              local gridW, gridH = cellSize * cols, cellSize * gridRows
              local gx = px + pad
              local gy = py + headerH + (gridAvailH - gridH) / 2
              local cellRad = (theme.radii and theme.radii.sm or 8) * uiScale

              for i = 1, 20 do
                  local c, r = (i - 1) % cols, math.floor((i - 1) / cols)
                  local cx, cy = gx + c * cellSize, gy + r * cellSize
                  local mon = activePcGrid.boxData[i]

                  if i == activePcGrid.index then
                      love.graphics.setColor(cSelected[1], cSelected[2], cSelected[3], (cSelected[4] or 1) * pOpac)
                  else
                      love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
                  end
                  
                  love.graphics.rectangle("fill", cx + 2 * uiScale, cy + 2 * uiScale, cellSize - 4 * uiScale, cellSize - 4 * uiScale, cellRad)

                  if mon then
                      local maxArtSize = cellSize * 0.68
                      local scale = math.min(maxArtSize / 16, maxArtSize / 16)
                      local qx = cx + (cellSize - 16 * scale) / 2
                      local qy = cy + (cellSize - 16 * scale) / 2
                      
                      drawBoxIconScaled(game, mon, qx, qy, i == activePcGrid.index, activePcGrid.blink, scale, pOpac)
                  end
              end

              -- THE DETAIL PANEL (RICH STATS & MOVES VIEW)
              local dx = gx + gridW + pad
              local dy = py + headerH
              local dh = panelH - headerH - footerH - pad
              
              love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
              love.graphics.rectangle("fill", dx, dy, detailW, dh, cellRad)
              
              local hoveredMon = activePcGrid.boxData[activePcGrid.index]
              if hoveredMon then
                  local def = game.data.pokemon[hoveredMon.species] or {}
                  local name = hoveredMon.nickname or def.name or hoveredMon.species or "?????"

                  local sm = 8 * uiScale
                  local md = 16 * uiScale
                  local lg = 24 * uiScale

                  local spriteImg = getLargeSprite(game, hoveredMon.species)
                  local artSize = math.min(100 * uiScale, detailW * 0.35)
                  local artX = dx + md
                  local artY = dy + md

                  if spriteImg then
                      local iw, ih = spriteImg:getWidth(), spriteImg:getHeight()
                      local scale = math.min(artSize / iw, artSize / ih)
                      
                      love.graphics.setColor(1, 1, 1, 1)
                      local prevShader = love.graphics.getShader()
                      local appliedShader = false
                      local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                      if okFX and PaletteFX and PaletteFX.monPal then
                          local pal = PaletteFX.monPal(game.data, hoveredMon.species)
                          if pal then
                              local shader = PaletteFX.shader()
                              if shader then
                                  pcall(PaletteFX.sendColors, shader, pal)
                                  love.graphics.setShader(shader)
                                  appliedShader = true
                              end
                          end
                      end

                      local qx = artX + (artSize - iw * scale) / 2
                      local qy = artY + (artSize - ih * scale) / 2
                      love.graphics.draw(spriteImg, qx, qy, 0, scale, scale)
                      if appliedShader then love.graphics.setShader(prevShader) end
                  end

                  local infoX = artX + artSize + md
                  local infoW = detailW - (infoX - dx) - md
                  
                  local bImg = nil
                  local icons = game.data.icons or {}
                  local iconDefs = icons.icons or {}
                  local ballEntry = iconDefs["BALL"] or iconDefs["ball"]
                  local ballPath = type(ballEntry) == "table" and (ballEntry.image or ballEntry.asset or ballEntry.path) or ballEntry
                  
                  if ballPath and type(ballPath) == "string" then
                      local bKey = ballPath .. "#raw"
                      if iconCache[bKey] == nil then
                          local okIcon, lImg = pcall(love.graphics.newImage, Assets.resolve(ballPath))
                          iconCache[bKey] = okIcon and lImg or false
                      end
                      bImg = iconCache[bKey]
                  end

                  local bSize = getScaledHeight(titleFont) * 0.8
                  local bScale = bImg and (bSize / bImg:getHeight()) or 1
                  local bWidth = bImg and (bImg:getWidth() * bScale + 8 * uiScale) or 0
                  
                  local startX = infoX
                  if bImg then
                      love.graphics.setColor(1, 1, 1, 1)
                      local prevShader = love.graphics.getShader()
                      local okFX, PaletteFX = pcall(require, "src.render.PaletteFX")
                      if okFX and PaletteFX and PaletteFX.monPal then
                          local pal = PaletteFX.monPal(game.data, "VOLTORB")
                          local shader = PaletteFX.shader()
                          if shader and pal then
                              pcall(PaletteFX.sendColors, shader, pal)
                              love.graphics.setShader(shader)
                          end
                      end
                      love.graphics.draw(bImg, startX, artY + (getScaledHeight(titleFont) - bSize)/2, 0, bScale, bScale)
                      love.graphics.setShader(prevShader)
                      startX = startX + bWidth
                  end

                  printScaled(name, startX, artY, titleFont, cText)

                  local lvlText = hoveredMon.level and ("Lv " .. hoveredMon.level) or ""
                  local speciesName = def.name and def.name ~= name and def.name or ""
                  local TypeChart
                  local okChart, resultChart = pcall(require, "src.battle.TypeChart")
                  if okChart then TypeChart = resultChart end
                  
                  local types = {}
                  for _, t in ipairs(def.types or {}) do
                      types[#types + 1] = TypeChart and TypeChart.displayName(t) or t
                  end
                  local typeStr = table.concat(types, " / ")
                  
                  local subtitleParts = {}
                  if lvlText ~= "" then table.insert(subtitleParts, lvlText) end
                  if speciesName ~= "" then table.insert(subtitleParts, speciesName) end
                  if typeStr ~= "" then table.insert(subtitleParts, typeStr) end
                  local subtitle = table.concat(subtitleParts, "  "):gsub("  +", "  ")
                  
                  local lineY = artY + getScaledHeight(titleFont) + 4 * uiScale
                  printScaled(subtitle, infoX, lineY, captionFont, cMuted)
                  
                  local stats = hoveredMon.stats
                  if not stats then
                      local ok, calcStats = pcall(Stats.calc, def, hoveredMon.level or 1, hoveredMon.dvs or {}, hoveredMon.statExp)
                      if ok and calcStats then stats = calcStats end
                  end
                  stats = stats or {}
                  
                  local maxHP = stats.hp or 0
                  local currentHP = hoveredMon.hp or maxHP
                  currentHP = math.min(currentHP, maxHP)
                  
                  lineY = lineY + getScaledHeight(captionFont) + 12 * uiScale
                  
                  if maxHP > 0 then
                      local barW = infoW
                      local barH = 8 * uiScale
                      local trackColor = {0.16, 0.22, 0.30, 1}
                      local hpColor = {0.18, 0.78, 0.72, 1}
                      local ratio = currentHP / maxHP
                      if ratio <= 0.20 then hpColor = {0.98, 0.47, 0.22, 1}
                      elseif ratio <= 0.50 then hpColor = {0.96, 0.72, 0.24, 1} end
                      
                      love.graphics.setColor(trackColor[1], trackColor[2], trackColor[3], (trackColor[4] or 1) * pOpac)
                      love.graphics.rectangle("fill", infoX, lineY, barW, barH, barH/2)
                      if ratio > 0 then
                          love.graphics.setColor(hpColor[1], hpColor[2], hpColor[3], (hpColor[4] or 1) * pOpac)
                          love.graphics.rectangle("fill", infoX, lineY, barW * ratio, barH, barH/2)
                      end
                      
                      lineY = lineY + barH + 6 * uiScale
                      
                      local hpStr = ("HP %d/%d"):format(currentHP, maxHP)
                      local statusStr = hoveredMon.status and (hoveredMon.status ~= "OK") and hoveredMon.status or ""
                      printScaled(hpStr, infoX, lineY, captionFont, cMuted)
                      if statusStr ~= "" then
                          local statW = getScaledWidth(statusStr, captionFont)
                          printScaled(statusStr:upper(), infoX + infoW - statW, lineY, captionFont, cAccent)
                      end
                  end

                  local lowerY = math.max(artY + artSize + md, lineY + getScaledHeight(captionFont) + lg)
                  
                  local statText = {
                    ("ATK %s"):format(tostring(stats.attack or "—")),
                    ("DEF %s"):format(tostring(stats.defense or "—")),
                    ("SPD %s"):format(tostring(stats.speed or "—")),
                    ("SPC %s"):format(tostring(stats.special or "—")),
                  }
                  
                  local statWidth = (detailW - md * 2 - sm * 3) / 4
                  for index, value in ipairs(statText) do
                      printScaled(value, dx + md + (index - 1) * (statWidth + sm), lowerY, bodyFont, cMuted)
                  end
                  
                  local lowerY2 = lowerY + getScaledHeight(bodyFont) + sm
                  local idStr = ("ID %05d"):format(tonumber(hoveredMon.otId or (game.save.player and game.save.player.id) or 0))
                  local otStr = ("OT %s"):format(tostring(hoveredMon.ot or (game.save.player and game.save.player.name) or "RED"))
                  
                  printScaled(idStr, dx + md, lowerY2, bodyFont, cMuted)
                  printScaled(otStr, dx + md + statWidth * 2 + sm * 2, lowerY2, bodyFont, cMuted)

                  love.graphics.setColor(cDivider[1], cDivider[2], cDivider[3], cDivider[4])
                  love.graphics.rectangle("fill", dx + md, lowerY2 + getScaledHeight(bodyFont) + sm, detailW - md * 2, 1 * uiScale)

                  local movesY = lowerY2 + getScaledHeight(bodyFont) + md + 4 * uiScale
                  local moves = hoveredMon.moves or {}
                  
                  local moveLineH = getScaledHeight(bodyFont) + sm
                  local availableMoveH = (dy + dh) - movesY - md
                  local moveGap = math.min(moveLineH + 6 * uiScale, availableMoveH / 4)

                  for index = 1, 4 do
                      local move = moves[index]
                      local moveDef = move and game.data and game.data.moves and game.data.moves[move.id]
                      local moveName = moveDef and moveDef.name or move and move.id or "—"
                      
                      local ppStr = ""
                      if move and moveDef then
                          local basePP = tonumber(moveDef.pp) or 0
                          local maxPP = basePP + (tonumber(move.ppUps) or 0) * math.floor(basePP / 5)
                          ppStr = ("PP %d/%d"):format(move.pp or 0, maxPP)
                      end
                      
                      local my = movesY + (index - 1) * moveGap
                      printScaled(moveName, dx + md, my, bodyFont, cText)
                      if ppStr ~= "" then
                          local ppW = getScaledWidth(ppStr, captionFont)
                          printScaled(ppStr, dx + detailW - md - ppW, my + (getScaledHeight(bodyFont) - getScaledHeight(captionFont))/2, captionFont, cMuted)
                      end
                  end

              else
                  printScaled("Empty Slot", dx + (detailW - getScaledWidth("Empty Slot", bodyFont))/2, dy + dh/2 - getScaledHeight(bodyFont)/2, bodyFont, cMuted)
              end

              love.graphics.setColor(cDivider[1], cDivider[2], cDivider[3], cDivider[4])
              love.graphics.rectangle("fill", px + pad, py + panelH - footerH - 4 * uiScale, panelW - pad * 2, 1 * uiScale)

              printScaled("LEFT/RIGHT  box   A  actions   B  back", px + pad, py + panelH - footerH + 4 * uiScale, captionFont, cMuted)

              -- EMBEDDED SUBMENU MODAL
              -- (Only draw if no Party/Stats menu is currently opened above us)
              if activePcGrid.subMenuOpen and isTop then
                  love.graphics.setColor(0, 0, 0, 0.4)
                  love.graphics.rectangle("fill", px, py, panelW, panelH, rad)

                  local menuW = 200 * uiScale
                  local menuH = 180 * uiScale
                  local mx = px + (panelW - menuW) / 2
                  local my = py + (panelH - menuH) / 2
                  
                  love.graphics.setColor(cRaised[1], cRaised[2], cRaised[3], (cRaised[4] or 1) * pOpac)
                  love.graphics.rectangle("fill", mx, my, menuW, menuH, theme.radii.md * uiScale)
                  
                  love.graphics.setColor(cAccent[1], cAccent[2], cAccent[3], cAccent[4])
                  love.graphics.rectangle("fill", mx, my, menuW, 4 * uiScale, theme.radii.md * uiScale)
                  
                  local options = {"WITHDRAW", "CHANGE", "RELEASE", "CANCEL"}
                  for i, opt in ipairs(options) do
                      local optY = my + 16 * uiScale + (i-1) * 36 * uiScale
                      if i == activePcGrid.subMenuIndex then
                          love.graphics.setColor(cSelected[1], cSelected[2], cSelected[3], (cSelected[4] or 1) * pOpac)
                          love.graphics.rectangle("fill", mx + 8 * uiScale, optY, menuW - 16 * uiScale, 32 * uiScale, theme.radii.sm * uiScale)
                          printScaled(opt, mx + 24 * uiScale, optY + 6 * uiScale, bodyFont, cText)
                      else
                          printScaled(opt, mx + 24 * uiScale, optY + 6 * uiScale, bodyFont, cMuted)
                      end
                  end
              end

              love.graphics.pop()
          end)
          if not ok then print("PcGrid Modern Draw Error: " .. tostring(err)) end
      end

      -- =========================================================================
      -- 3. PASS TO MODERN UI 
      -- (It now only sees Overworld + Party Menu, so it draws Party natively on top!)
      -- =========================================================================
      nextFn(unpack(args))

      -- =========================================================================
      -- 4. RESTORE THE STACK
      -- =========================================================================
      if isGridActive then
          for i = #game.stack.states, 1, -1 do table.remove(game.stack.states, i) end
          for _, s in ipairs(originalStates) do table.insert(game.stack.states, s) end
      end
  end, 100)
end